<?php 

class AVService extends ADOdb_Active_Record {
	
	var $_table = "service";
	
}

?>
