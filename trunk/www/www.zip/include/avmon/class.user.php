<?php 

class AVUser extends ADOdb_Active_Record {
	
	var $_table = "user";
	
}

?>