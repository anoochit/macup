<?php 

class AVMonitor extends ADOdb_Active_Record {
	
	var $_table = "monitor";
	
}

?>
