<?php 

class AVLog extends ADOdb_Active_Record {
	
	var $_table = "log";
	
}

?>
