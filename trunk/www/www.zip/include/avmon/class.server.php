<?php 

class AVServer extends ADOdb_Active_Record {
	
	var $_table = "server";
	
}

?>
